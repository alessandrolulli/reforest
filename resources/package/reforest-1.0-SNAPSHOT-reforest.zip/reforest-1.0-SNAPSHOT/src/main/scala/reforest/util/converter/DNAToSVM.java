/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reforest.util.converter;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

public class DNAToSVM
{
    public static void main(String[] args_) throws Exception {
        String inputDATA = args_[0];
        String inputLABEL = args_[1];
        String output = args_[2];

        final FileReader frDATA = new FileReader(inputDATA);
        final LineNumberReader lnrDATA = new LineNumberReader(frDATA);

        final FileReader frLABEL = new FileReader(inputLABEL);
        final LineNumberReader lnrLABEL = new LineNumberReader(frLABEL);

        final FileOutputStream fileStreamOutput = new FileOutputStream(output, true);
        final PrintStream printOutput = new PrintStream(fileStreamOutput);

        String lineDATA;
        String lineLABEL;

        Map<Character, Integer> map = new HashMap<>();
        map.put('A', 1);
        map.put('C', 2);
        map.put('G', 3);
        map.put('T', 4);

        while ((lineDATA = lnrDATA.readLine()) != null & (lineLABEL = lnrLABEL.readLine()) != null)
        {
            StringBuilder b = new StringBuilder();
            b.append(lineLABEL);

            for(int i = 0 ; i < lineDATA.length() ; i++)
            {
                b.append(" ");
                b.append(i+1);
                b.append(":");
                b.append(map.get(lineDATA.charAt(i)));
            }

            printOutput.println(b.toString());
        }

        printOutput.close();
        lnrDATA.close();
        lnrLABEL.close();
    }
}

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reforest.util.converter;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

public class ARFFtoSVM
{
    public static void main(String[] args_) throws Exception {
        String inputDATA = args_[0];
        String output = args_[1];

        final FileReader frDATA = new FileReader(inputDATA);
        final LineNumberReader lnrDATA = new LineNumberReader(frDATA);

        final FileOutputStream fileStreamOutput = new FileOutputStream(output, true);
        final PrintStream printOutput = new PrintStream(fileStreamOutput);

        String lineDATA;
        int count = 0;

        while ((lineDATA = lnrDATA.readLine()) != null)
        {
            if(lineDATA.isEmpty() || lineDATA.startsWith("%") || lineDATA.startsWith("@")) {

            } else {
                String[] value = lineDATA.split(",");

                StringBuilder b = new StringBuilder();

                int label = (int) Double.parseDouble(value[value.length - 1]);
                b.append(label < 0 ? 0 : label);

                for (int i = 0; i < value.length - 1; i++) {
                    b.append(" ");
                    b.append(i + 1);
                    b.append(":");
                    b.append(value[i]);
                }

                printOutput.println(b.toString());
            }

            if(count % 100 == 0) printOutput.flush();
            count++;
        }

        printOutput.close();
        lnrDATA.close();
    }
}

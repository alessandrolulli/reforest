/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package stats;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.util.DoubleArray;
import scala.Option;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class StatsAnalyzerAutomatic
{
    private static final String NUMTREES = "numTrees";
    private static final String DEPTH = "maxDepth";
    private static final String BINNUMBER = "binNumber";
    private static final String CORE = "sparkCoresMax";
    private static final String EXECUTOR = "sparkExecutorInstances";

    private static final String TIME = "timeALL";
    private static final String TIMEPREPARATION = "timePREPARATION";
    private static final String ACCURACY = "testError";

    static class Group
    {
        private final String _algorithm;
        private final String _dataset;
        private final Double _numTrees;
        private final Double _depth;
        private final Double _bin;
        private final Double _core;
        private final Double _executor;

        private final String _all;

        public Group(String[] token_)
        {
            _algorithm = token_[0];
            _dataset = token_[1];
            _numTrees = getValue(NUMTREES, token_).get();
            _depth = getValue(DEPTH, token_).get();
            _bin = getValue(BINNUMBER, token_).get();
            _core = getValue(CORE, token_).get();
            _executor = getValue(EXECUTOR, token_).get();

            _all = _algorithm+","+_dataset+","+_executor+","+_core+","+_numTrees+","+_depth+","+_bin;
        }

        @Override
        public int hashCode()
        {
            return _all.hashCode();
        }

        @Override
        public boolean equals(Object other_)
        {
            return _all.equals(other_);
        }

        public String toString()
        {
            return _all;
        }

    }

    private static Option<Double> getValue(String key_, String[] token_)
    {
        Option<Double> toReturn = Option.<Double>empty();
        int i = 0;
        boolean getNext = false;
        while(i < token_.length && toReturn.isEmpty())
        {
            if(getNext)
            {
                toReturn = Option.apply(Double.parseDouble(token_[i]));
            }
            if(token_[i].equals(key_))
            {
                getNext = true;
            }

            i++;
        }

        return toReturn;
    }

    public static void main(String[] args_)
    {
        // args_[0] INPUT

        if(args_.length != 1)
        {
            System.out.println("USAGE: command input");
        } else {
            try {
                final FileReader fr = new FileReader(args_[0]);
                final LineNumberReader lnr = new LineNumberReader(fr);
                String line;

                Map<String, DescriptiveStatistics[]> stats = new HashMap<>();

                while ((line = lnr.readLine()) != null) {

                    String update = line.replace("preparationTime", TIMEPREPARATION);
                    String[] token = update.split(",");

                    Group g = new Group(token);

                    DescriptiveStatistics[] t = stats.get(g.toString());
                    DescriptiveStatistics time = null;
                    DescriptiveStatistics timePreparation = null;
                    DescriptiveStatistics accuracy = null;
                    if(t == null)
                    {
                        time = new DescriptiveStatistics();
                        timePreparation = new DescriptiveStatistics();
                        accuracy = new DescriptiveStatistics();
                        t = new DescriptiveStatistics[]{time, timePreparation, accuracy};

                        stats.put(g.toString(), t);
                    } else
                    {
                        time = t[0];
                        timePreparation = t[1];
                        accuracy = t[2];
                    }

                    time.addValue(getValue(TIME, token).get());
                    timePreparation.addValue(getValue(TIMEPREPARATION, token).get());
                    accuracy.addValue(getValue(ACCURACY, token).get());
                }

                lnr.close();

                StringBuilder builder = new StringBuilder();
                builder.append("algorithm,dataset,executor,core,tree,depth,bin,population,time,timeSTDDEV,accuracy,accuracySTDDEV \n");

                for (Map.Entry<String, DescriptiveStatistics[]> v : stats.entrySet()) {
                    builder.append(v.getKey().toString() +","+v.getValue()[0].getN()+ ","+ v.getValue()[0].getMean() + ","+ v.getValue()[0].getStandardDeviation()+",");
//                    builder.append(v.getValue()[1].getMean()+","+v.getValue()[1].getVariance()+","+v.getValue()[1].getStandardDeviation()+",");
                    builder.append(v.getValue()[2].getMean()+","+v.getValue()[2].getStandardDeviation()+"\n");
                }

                System.out.println(builder.toString());

            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reforest.util.converter;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintStream;

public class SVMtoDENSE
{
    public static void main(String[] args_) throws Exception {
        String input = args_[0];
        String output = args_[1];
        int numFeatures = Integer.parseInt(args_[2]);

        final FileReader fr = new FileReader(input);
        final LineNumberReader lnr = new LineNumberReader(fr);

        final FileOutputStream fileStreamOutput = new FileOutputStream(output);
        final PrintStream printOutput = new PrintStream(fileStreamOutput);

        String line;

        while ((line = lnr.readLine()) != null)
        {
            String[] lineSplitted = line.split(" ");

            StringBuilder builder = new StringBuilder();
            builder.append(lineSplitted[0].equals("-1") ? 0 : lineSplitted[0]);

            String[] values = new String[numFeatures];
            for(int i = 1 ; i < lineSplitted.length ; i++)
            {
                String[] token = lineSplitted[i].split(":");
                int index = Integer.parseInt(token[0]) - 1;
                values[index] = token[1];
            }
            for(String d : values)
            {
                builder.append(" ");
                builder.append(d);
            }
            printOutput.println(builder.toString());
        }

        lnr.close();
        printOutput.close();
    }
}

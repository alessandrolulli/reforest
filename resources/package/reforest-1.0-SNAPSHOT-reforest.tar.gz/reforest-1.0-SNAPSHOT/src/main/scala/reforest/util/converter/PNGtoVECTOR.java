/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reforest.util.converter;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class PNGtoVECTOR {
    public static void main(String[] args_) throws Exception {

        String input = args_[0];
        String output = args_[1];

        String label = args_[2];

        File file = new File(input);

        final FileOutputStream fileStreamOutput = new FileOutputStream(output, true);
        final PrintStream printOutput = new PrintStream(fileStreamOutput);

        List<String> failed = new ArrayList<>();
        for (File imgFile : file.listFiles()) {
            try {
                BufferedImage img = ImageIO.read(imgFile);
                final byte[] imageData = ((DataBufferByte) img.getRaster().getDataBuffer()).getData();

                StringBuilder builder = new StringBuilder();
                builder.append(label);
                for (int i = 0; i < imageData.length; i++) {
                    int index = i + 1;
                    builder.append(" ");
                    builder.append(index);
                    builder.append(":");
                    builder.append(imageData[i]);
                }

                printOutput.println(builder.toString());
            } catch (Exception e) {
                failed.add(imgFile.getName());
                e.printStackTrace();
            }
        }

        for(String f : failed)
        {
            System.out.println(f);
        System.out.println("FAILED: "+failed.size());
        printOutput.close();
    }

}

}

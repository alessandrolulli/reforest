/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reforest.util.converter;

import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.*;

public class DATAStat
{
    static <K,V extends Comparable<? super V>>
    SortedSet<Map.Entry<K,V>> entriesSortedByValues(Map<K,V> map) {
        SortedSet<Map.Entry<K,V>> sortedEntries = new TreeSet<Map.Entry<K,V>>(
                new Comparator<Map.Entry<K,V>>() {
                    @Override public int compare(Map.Entry<K,V> e1, Map.Entry<K,V> e2) {
                        int res = e2.getValue().compareTo(e1.getValue());
                        return res != 0 ? res : 1;
                    }
                }
        );
        sortedEntries.addAll(map.entrySet());
        return sortedEntries;
    }

    public static void main(String[] args_) throws Exception {
        String input = args_[0];
        String separator = args_[1];

        final FileReader fr = new FileReader(input);
        final LineNumberReader lnr = new LineNumberReader(fr);

        String line;

        List<Map<String, Integer>> valueList = new ArrayList<Map<String, Integer>>();

        while ((line = lnr.readLine()) != null)
        {
            String[] lineSplitted = line.split(separator);

            for(int i = 0 ; i < lineSplitted.length ; i++)
            {
                if(valueList.size() < (i+1))
                {
                    valueList.add(new HashMap<String, Integer>());
                }

                Map<String, Integer> valueMap = valueList.get(i);
                Integer valueCount = valueMap.get(lineSplitted[i]);

                if(valueCount == null)
                {
                    valueMap.put(lineSplitted[i], 1);
                } else
                {
                    valueMap.put(lineSplitted[i], valueCount + 1);
                }
            }
        }

        for(int i = 0 ; i < valueList.size() ; i++)
        {
            Map<String, Integer> mapValue = valueList.get(i);

            StringBuilder b = new StringBuilder();
            b.append(i);
            b.append(" ");
            b.append(mapValue.size());

            for(Map.Entry entry : entriesSortedByValues(mapValue))
            {
                b.append(" ");
                b.append(entry.getKey());
                b.append(":");
                b.append(entry.getValue());
            }
            System.out.println(b.toString());
        }

        lnr.close();
    }
}

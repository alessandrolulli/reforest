/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package stats;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import scala.Tuple2;
import sun.security.krb5.internal.crypto.Des;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class StatsAnalyzer
{
    static class Command
    {
        private final String _c;
        private final String _val;

        public Command(String[] args_, int index_)
        {
            _c = args_[index_];
            _val = args_[++index_];
        }

        public String getCommand()
        {
            return _c;
        }

        public String getValue()
        {
            return _val;
        }

    }

    private static Map<String, String> getAllCommand(String[] args_)
    {
        Map<String, String> toReturn = new HashMap<>();

        for(int i = 1; i < args_.length; i++)
        {
            if(i%2 == 1)
            {
                Command c = new Command(args_, i);
                toReturn.put(c.getCommand(), c.getValue());
            }
        }

        return toReturn;
    }

    public static void main(String[] args_)
    {
        // args_[0] INPUT

        if(args_.length < 3)
        {
            System.out.println("USAGE: command input [command value]*");
            System.out.println("COMMANDS: column, separator, groupBy, divisor");
        } else {


            try {
                final FileReader fr = new FileReader(args_[0]);
                final LineNumberReader lnr = new LineNumberReader(fr);
                String line;

                Map<String, String> toReturn = getAllCommand(args_);

                String separator = toReturn.containsKey("separator") ? toReturn.get("separator") : ",";
                int groupBy = toReturn.containsKey("groupBy") ? Integer.parseInt(toReturn.get("groupBy")) : -1;
                int divisor = toReturn.containsKey("divisor") ? Integer.parseInt(toReturn.get("divisor")) : 1;
                int columnData = toReturn.containsKey("column") ? Integer.parseInt(toReturn.get("column")) : 1;

                Map<String, DescriptiveStatistics> statsMAP = new TreeMap<>();

                while ((line = lnr.readLine()) != null) {
                    String[] token = line.split(separator);

                    if (groupBy != -1) {
                        DescriptiveStatistics stats = statsMAP.get(token[groupBy]);

                        if (stats == null) {
                            stats = new DescriptiveStatistics();
                            statsMAP.put(token[groupBy], stats);
                        }

                        stats.addValue(Double.parseDouble(token[columnData]) / divisor);
                    } else {
                        DescriptiveStatistics stats = statsMAP.get("ALL");

                        if (stats == null) {
                            stats = new DescriptiveStatistics();
                            statsMAP.put("ALL", stats);
                        }

                        stats.addValue(Double.parseDouble(token[columnData]) / divisor);
                    }
                }

                lnr.close();

                StringBuilder builder = new StringBuilder();
                builder.append("group,populationsize,mean,variance,stdev\n");

                for (Map.Entry<String, DescriptiveStatistics> v : statsMAP.entrySet()) {
                    builder.append(v.getKey() + ","+ v.getValue().getN() + ","+ v.getValue().getMean() + ","+ v.getValue().getVariance() + ","+ v.getValue().getStandardDeviation() + "\n");
//                    builder.append(v.getKey() + " ");
//                    builder.append("POPULATION: " + v.getValue().getN() + " ");
//                    builder.append("MEAN: " + v.getValue().getMean() + " ");
//                    builder.append("VARIANCE: " + v.getValue().getVariance() + " ");
//                    builder.append("STDEV: " + v.getValue().getStandardDeviation() + "\n");
                }

                System.out.println(builder.toString());

            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reforest.util.converter;

import scala.Tuple2;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClickLogsToSVM
{
    public static void main(String[] args_) throws Exception {
        String input = args_[0];
        String output = args_[1];
        String separator = args_[2];
        int indexToStart = Integer.parseInt(args_[3]);

        final FileReader fr = new FileReader(input);
        final LineNumberReader lnr = new LineNumberReader(fr);

        final FileOutputStream fileStreamOutput = new FileOutputStream(output, true);
        final PrintStream printOutput = new PrintStream(fileStreamOutput);

        String line;

        List<Map<String, Tuple2<Integer,Integer>>> valueList = new ArrayList<Map<String, Tuple2<Integer,Integer>>>();
        //key, (value, frequency)

        while ((line = lnr.readLine()) != null)
        {
            String[] lineSplitted = line.split(separator);
            StringBuilder b = new StringBuilder();

            for(int i = 0 ; i < lineSplitted.length ; i++)
            {
                if(valueList.size() < (i+1))
                {
                    valueList.add(new HashMap<String, Tuple2<Integer,Integer>>());
                }

                if(i>=indexToStart)
                {
                    Map<String, Tuple2<Integer,Integer>> valueMap = valueList.get(i);
                    Tuple2<Integer,Integer> valueCount = valueMap.get(lineSplitted[i]);

                    if(valueCount == null)
                    {
                        valueCount = new Tuple2<>(valueMap.size() + 1, 1);
                        valueMap.put(lineSplitted[i], valueCount);
                    } else
                    {
                        valueCount = new Tuple2<>(valueCount._1(), valueCount._2() + 1);
                        valueMap.put(lineSplitted[i], valueCount);
                    }

                    b.append(" ");
                    b.append(i);
                    b.append(":");
                    b.append(valueCount._1());
                } else
                {
                    if(i == 0)
                    {
                        b.append(lineSplitted[i]);
                    } else
                    {
                        if(!lineSplitted[i].isEmpty()) {
                            b.append(" ");
                            b.append(i);
                            b.append(":");
                            b.append(lineSplitted[i]);
                        }
                    }
                }
            }

            printOutput.println(b.toString());
        }

        printOutput.close();
        lnr.close();

        for(int i = indexToStart ; i < valueList.size() ; i++)
        {
            final PrintStream printDictionary = new PrintStream(output+"-column-"+i);

            Map<String, Tuple2<Integer,Integer>> valueMap = valueList.get(i);
            for(Map.Entry<String, Tuple2<Integer,Integer>> entry : valueMap.entrySet())
            {
                StringBuilder b = new StringBuilder();
                b.append(entry.getKey());
                b.append("\t");
                b.append(entry.getValue()._1());
                b.append("\t");
                b.append(entry.getValue()._2());
                printDictionary.println(b.toString());
            }

            printDictionary.close();
        }
    }
}
